create procedure transfer(IN sender_card character varying, IN receiver_card character varying, IN amount integer, OUT status_message character varying)
    language plpgsql
as
$$
begin
    --check if the from account has enough balance
  if  (select balance from accounts where card_number = sender_card) < amount then
      status_message := 'Insufficient funds';
      return;
  end if;
  -- Perform the transaction
  begin
        -- Subtract amount from the sender's account
      update accounts 
      set balance = balance - amount
      where card_number = sender_card;
    
    -- Add amount to the receiver's account
      update accounts 
      set balance = balance + amount
      where card_number = receiver_card;
    
    --set the status message
    status_message := 'Transfer is succesfull';
  exception
      when others then
        -- Rollback and set the status message if any error occurs.
      rollback;
      status_message := 'Transfer is failed';
  end;  
end;
$$;

alter procedure transfer(varchar, varchar, integer, out varchar) owner to postgres;

