create function select_users() returns SETOF users
    language plpgsql
as
$$
  begin
      select * from users;
  end;
  $$;

alter function select_users() owner to postgres;

