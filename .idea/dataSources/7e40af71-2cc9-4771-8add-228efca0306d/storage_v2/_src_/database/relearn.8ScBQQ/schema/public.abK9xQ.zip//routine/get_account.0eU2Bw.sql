create procedure get_account(IN p_id integer, OUT id integer, OUT username character varying, OUT phone_number character varying, OUT balance integer, OUT card_number character varying)
    language plpgsql
as
$$
begin
    select a.id, a.username, a.phone_number, a.balance, a.card_number
	into id, username, phone_number, balance, card_number
	from accounts a
	where a.id = p_id;
end;
$$;

alter procedure get_account(integer, out integer, out varchar, out varchar, out integer, out varchar) owner to postgres;

