create function get_accounts()
    returns TABLE(id integer, username character varying, phone_number character varying, balance integer, card_number character varying)
    language plpgsql
as
$$
begin
    return query select * from accounts;
end;
$$;

alter function get_accounts() owner to postgres;

