create procedure add_account(IN p_username character varying, IN p_phone_number character varying, IN p_balance integer, IN p_card_number character varying, OUT status_message character varying)
    language plpgsql
as
$$
begin
    -- Check if the card number has more than 16 digits
	if length(p_card_number)<> 16 then
	    status_message := 'Card number exceeds 16 digits';
		return;
	end if;
	
	-- Insert into accounts table
    insert into accounts(username,phone_number,balance,card_number)
	values (p_username,p_phone_number,p_balance,p_card_number);
	
	status_message := 'Account added successfully';
end;
$$;

alter procedure add_account(varchar, varchar, integer, varchar, out varchar) owner to postgres;

