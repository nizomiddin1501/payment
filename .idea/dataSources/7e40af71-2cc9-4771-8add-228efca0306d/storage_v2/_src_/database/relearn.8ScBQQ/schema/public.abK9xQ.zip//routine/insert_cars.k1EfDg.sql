create procedure insert_cars(IN type character varying, IN maker character varying, IN price character varying)
    language plpgsql
as
$$
 begin
      insert into cars(type,maker,price)
	  values (type,maker,price);
 end;
 $$;

alter procedure insert_cars(varchar, varchar, varchar) owner to postgres;

