create procedure insert_users(IN firstname character varying, IN lastname character varying, IN username character varying, IN password character varying)
    language plpgsql
as
$$
  begin
       insert into users(firstname,lastname,username,password)
     values (firstname,lastname,username,password);
	 commit;
  end;
  $$;

alter procedure insert_users(varchar, varchar, varchar, varchar) owner to postgres;

